<header class="relative z-40 bg-white/90 backdrop-blur-md border-b border-(--border) shadow-sm">

    <!-- ================= TOP HEADER ================= -->
    <div class="container mx-auto px-4">

        <div class="flex items-center justify-between py-2 md:py-3">

            <!-- Logo -->
            <a href="/" class="flex items-center group [perspective:600px]">
                <img src="{{ asset('frontend/images/logo.png') }}" alt="NewsHub Logo"
                    class="h-12 sm:h-16 md:h-20 w-auto transition-transform duration-300 ease-out group-hover:scale-[1.03] group-hover:[transform:rotateY(-4deg)]">
            </a>

            <!-- Date / Tagline -->
            <div class="hidden sm:flex flex-col items-end text-right">

                <span id="date" class="font-ui text-sm md:text-base lg:text-lg font-bold tracking-tight text-(--text-primary)">
                    बुधबार, २७ साउन २०८३
                </span>

                <span class="mt-1 h-0.5 w-28 md:w-44 rounded-full" style="background: var(--gradient-signature);"></span>

                <span class="mt-1 text-xs md:text-sm text-(--text-muted)">
                    तपाईंको दैनिक समाचार स्रोत
                </span>

            </div>

        </div>

    </div>


</header>

<!-- ================= NAVIGATION ================= -->
<nav class="sticky top-0 z-50 glass-surface-dark depth-shadow-2">

        <!-- ================= DESKTOP NAV ================= -->
        <div class="container mx-auto px-4 hidden md:flex items-center justify-between gap-4">

            <!-- Navigation Links -->
            <ul class="flex items-center gap-1 overflow-x-auto whitespace-nowrap">

                <li>
                        <a href="/"
                            class="relative flex items-center gap-2 px-4 py-3 text-sm font-semibold text-white transition-colors duration-200 hover:text-blue-300 after:absolute after:bottom-1 after:left-4 after:right-4 after:h-0.5 after:scale-x-0 after:bg-(--secondary) after:transition-transform after:duration-300 hover:after:scale-x-100">
                            गृहपृष्ठ
                        </a>
                    </li>

                @foreach ($categories as $category)
                    <li>
                        <a href="{{route('category', $category->slug)}}"
                            class="relative flex items-center gap-2 px-4 py-3 text-sm font-semibold text-white transition-colors duration-200 hover:text-blue-300 after:absolute after:bottom-1 after:left-4 after:right-4 after:h-0.5 after:scale-x-0 after:bg-(--secondary) after:transition-transform after:duration-300 hover:after:scale-x-100">
                            {{ $category->title }}
                        </a>
                    </li>
                @endforeach

            </ul>


            <!-- Desktop Search -->
            <form action="{{route('search')}}" method="GET" class="relative w-48 lg:w-64 shrink-0">

                <input type="text" name="q" placeholder="Search news..."
                    class="w-full rounded-full bg-white/10 border border-white/20 py-2 pl-4 pr-10 text-sm text-white placeholder:text-slate-300 transition focus:border-(--secondary) focus:bg-white/15 focus:outline-none focus:ring-2 focus:ring-(--secondary)">

                <button type="submit"
                    class="absolute right-3 top-1/2 -translate-y-1/2 text-slate-300 transition hover:text-white">
                    <i class="fa-solid fa-magnifying-glass"></i>
                </button>

            </form>

        </div>


        <!-- ================= MOBILE NAV ================= -->
        <div class="md:hidden">

            <div class="container mx-auto px-4">

                <div class="flex items-center justify-between py-2">

                    <!-- Mobile brand -->
                    <span class="font-ui text-lg font-bold tracking-tight text-white">
                        NewsHub
                    </span>

                    <!-- Menu button -->

                    <button id="menu-button" type="button"
                        class="flex h-10 w-10 items-center justify-center rounded-lg text-white transition hover:bg-white/10 active:scale-95">
                        <i class="fa-solid fa-bars text-xl"></i>
                    </button>

                </div>

            </div>

        </div>

</nav>


<!-- ================= MOBILE DRAWER ================= -->

<div id="nav-drawer"
    class="fixed top-0 left-0 z-60 h-screen w-full sm:w-80 -translate-x-full overflow-y-auto glass-surface depth-shadow-3 border-r border-(--border) transition-transform duration-300 ease-out"
    tabindex="-1" aria-labelledby="drawer-label">

    <!-- Drawer Header -->
    <div class="flex items-center justify-between border-b border-(--border) px-5 py-4">

        <div class="flex items-center gap-2">

            <i class="fa-solid fa-newspaper text-(--secondary) text-xl"></i>

            <h5 id="drawer-label" class="text-lg font-bold text-(--primary)">
                NewsHub
            </h5>

        </div>


        <!-- Close -->
        <button id="close-menu" type="button"
            class="flex h-9 w-9 items-center justify-center rounded-lg text-(--text-muted) transition hover:bg-(--bg-secondary) hover:text-(--primary)">
            <i class="fa-solid fa-xmark text-lg"></i>

            <span class="sr-only">
                Close menu
            </span>
        </button>

    </div>


    <!-- Mobile Links -->
    <ul class="flex flex-col gap-1 p-4">

        <li>
            <a href="/"
                class="flex items-center gap-3 rounded-lg px-4 py-3 font-semibold text-(--text-primary) transition hover:bg-(--bg-secondary) hover:text-(--secondary)">
                <i class="fa-solid fa-house w-5"></i>
                Home
            </a>
        </li>


        <li>
            <a href="/categories"
                class="flex items-center gap-3 rounded-lg px-4 py-3 font-semibold text-(--text-primary) transition hover:bg-(--bg-secondary) hover:text-(--secondary)">
                <i class="fa-solid fa-layer-group w-5"></i>
                Categories
            </a>
        </li>


        <li>
            <a href="/about"
                class="flex items-center gap-3 rounded-lg px-4 py-3 font-semibold text-(--text-primary) transition hover:bg-(--bg-secondary) hover:text-(--secondary)">
                <i class="fa-solid fa-circle-info w-5"></i>
                About
            </a>
        </li>


        <li>
            <a href="/contact"
                class="flex items-center gap-3 rounded-lg px-4 py-3 font-semibold text-(--text-primary) transition hover:bg-(--bg-secondary) hover:text-(--secondary)">
                <i class="fa-solid fa-envelope w-5"></i>
                Contact
            </a>
        </li>

    </ul>


    <!-- Mobile Search -->
    <div class="border-t border-(--border) p-4">

        <form action="/search" method="GET" class="relative">

            <input type="text" name="q" placeholder="Search news..."
                class="w-full rounded-lg border border-(--border) bg-(--bg-light) py-3 pl-4 pr-10 text-sm text-(--text-primary) placeholder:text-(--text-muted) focus:border-(--secondary) focus:outline-none focus:ring-2 focus:ring-(--secondary)">

            <button type="submit"
                class="absolute right-3 top-1/2 -translate-y-1/2 text-(--text-muted) hover:text-(--secondary)">
                <i class="fa-solid fa-magnifying-glass"></i>
            </button>

        </form>

    </div>

</div>
