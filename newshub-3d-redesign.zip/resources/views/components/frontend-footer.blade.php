<footer class="relative overflow-hidden bg-(--primary) text-white">

    <div class="container mx-auto flex flex-col items-center justify-between gap-2 px-4 py-6 sm:flex-row">

        <div class="flex items-center gap-2">
            <i class="fa-solid fa-newspaper text-(--secondary)"></i>
            <span class="font-ui text-sm font-semibold tracking-tight">NewsHub</span>
        </div>

        <p class="text-xs text-slate-300">
            &copy; {{ date('Y') }} NewsHub. All rights reserved.
        </p>

    </div>

    <div class="h-1 w-full" style="background: var(--gradient-signature);"></div>

</footer>
