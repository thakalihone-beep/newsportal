import './bootstrap';
import 'flowbite';

import { initTilt } from './modules/tilt';
import { initScrollReveal, initParallax } from './modules/scroll-reveal';
import { initHeroStack } from './modules/hero-stack';

function initAll() {
    initTilt();
    initScrollReveal();
    initParallax();
    initHeroStack();
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initAll);
} else {
    initAll();
}
