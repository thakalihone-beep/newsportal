/**
 * Hero "front page stack" — the homepage signature element.
 * Three latest articles are rendered as physically stacked glass panels
 * (see home.blade.php [data-hero-stack]). This module only handles the
 * pointer-parallax tilt of that stack, plus an optional, very light
 * Three.js particle layer behind it that reads as dust/light through glass.
 *
 * Three.js is used ONLY here, and only on desktop/fine-pointer/no-reduced-motion,
 * because it's the one place genuine WebGL depth (soft, additive-blended points
 * drifting behind translucent panels) buys something CSS can't do cheaply.
 */

function prefersReducedMotion() {
    return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
}

function isCoarsePointer() {
    return window.matchMedia('(pointer: coarse)').matches;
}

function initStackParallax(stackEl) {
    const panels = stackEl.querySelectorAll('[data-hero-panel]');

    function onMove(e) {
        const rect = stackEl.getBoundingClientRect();
        const x = (e.clientX - rect.left) / rect.width - 0.5;
        const y = (e.clientY - rect.top) / rect.height - 0.5;

        panels.forEach((panel, i) => {
            // Panels further back in the stack move a little more (parallax).
            const depth = i + 1;
            const rotateY = x * 6 * depth * 0.4;
            const rotateX = -y * 6 * depth * 0.4;
            const translateZ = i * -24;
            const translateX = x * 6 * depth;
            const translateY = y * 4 * depth;

            panel.style.transform =
                `translate3d(${translateX.toFixed(1)}px, ${translateY.toFixed(1)}px, ${translateZ}px) ` +
                `rotateX(${rotateX.toFixed(2)}deg) rotateY(${rotateY.toFixed(2)}deg)`;
        });
    }

    function onLeave() {
        panels.forEach((panel, i) => {
            panel.style.transform = `translate3d(0, 0, ${i * -24}px) rotateX(0deg) rotateY(0deg)`;
        });
    }

    stackEl.addEventListener('pointermove', onMove);
    stackEl.addEventListener('pointerleave', onLeave);

    return () => {
        stackEl.removeEventListener('pointermove', onMove);
        stackEl.removeEventListener('pointerleave', onLeave);
    };
}

async function initParticles(canvas) {
    // Dynamic import so Three.js is never fetched on pages/devices that don't need it.
    const THREE = await import('three');

    const parent = canvas.parentElement;
    let width = parent.clientWidth;
    let height = parent.clientHeight;

    const renderer = new THREE.WebGLRenderer({
        canvas,
        alpha: true,
        antialias: false,
        powerPreference: 'low-power',
    });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5));
    renderer.setSize(width, height);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(50, width / height, 1, 1000);
    camera.position.z = 220;

    const COUNT = 70;
    const positions = new Float32Array(COUNT * 3);
    for (let i = 0; i < COUNT; i++) {
        positions[i * 3] = (Math.random() - 0.5) * 400;
        positions[i * 3 + 1] = (Math.random() - 0.5) * 300;
        positions[i * 3 + 2] = (Math.random() - 0.5) * 200;
    }

    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));

    const material = new THREE.PointsMaterial({
        color: 0x2563eb,
        size: 2.4,
        transparent: true,
        opacity: 0.35,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
    });

    const points = new THREE.Points(geometry, material);
    scene.add(points);

    let rafId;
    let disposed = false;

    function animate() {
        if (disposed) return;
        points.rotation.y += 0.0008;
        points.rotation.x += 0.0002;
        renderer.render(scene, camera);
        rafId = requestAnimationFrame(animate);
    }
    animate();

    function onResize() {
        width = parent.clientWidth;
        height = parent.clientHeight;
        camera.aspect = width / height;
        camera.updateProjectionMatrix();
        renderer.setSize(width, height);
    }
    window.addEventListener('resize', onResize);

    function dispose() {
        disposed = true;
        cancelAnimationFrame(rafId);
        window.removeEventListener('resize', onResize);
        geometry.dispose();
        material.dispose();
        renderer.dispose();
    }

    // Clean up on navigation away from the page to avoid leaking GPU resources.
    window.addEventListener('pagehide', dispose, { once: true });

    return dispose;
}

export function initHeroStack(root = document) {
    const stackEl = root.querySelector('[data-hero-stack]');
    if (!stackEl) return () => {};

    const cleanups = [];

    if (!prefersReducedMotion() && !isCoarsePointer()) {
        cleanups.push(initStackParallax(stackEl));

        const canvas = root.querySelector('[data-hero-particles]');
        if (canvas && window.innerWidth >= 768) {
            initParticles(canvas).then((dispose) => cleanups.push(dispose));
        }
    }

    return () => cleanups.forEach((fn) => fn && fn());
}
