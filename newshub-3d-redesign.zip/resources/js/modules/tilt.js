/**
 * Lightweight CSS-3D tilt for [data-tilt] cards.
 * - Attaches to every element with [data-tilt] found in the document.
 * - Rotation is capped (default 7deg) so cards stay readable.
 * - No-ops on touch/coarse pointers and prefers-reduced-motion.
 * - Pure CSS transforms — no WebGL, so it's cheap to run on every card in a grid.
 */

const MAX_DEG = 7;

function prefersReducedMotion() {
    return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
}

function isCoarsePointer() {
    return window.matchMedia('(pointer: coarse)').matches;
}

function bindTilt(card) {
    const inner = card.querySelector('[data-tilt-inner]') || card;

    function onMove(e) {
        const rect = card.getBoundingClientRect();
        const x = (e.clientX - rect.left) / rect.width;   // 0..1
        const y = (e.clientY - rect.top) / rect.height;   // 0..1

        const rotateY = (x - 0.5) * (MAX_DEG * 2);
        const rotateX = (0.5 - y) * (MAX_DEG * 2);

        inner.style.transform =
            `rotateX(${rotateX.toFixed(2)}deg) rotateY(${rotateY.toFixed(2)}deg) translateZ(0)`;
    }

    function onLeave() {
        inner.style.transform = 'rotateX(0deg) rotateY(0deg) translateZ(0)';
    }

    card.addEventListener('pointermove', onMove);
    card.addEventListener('pointerleave', onLeave);

    // Return a cleanup fn in case a page ever needs to tear this down.
    return () => {
        card.removeEventListener('pointermove', onMove);
        card.removeEventListener('pointerleave', onLeave);
    };
}

export function initTilt(root = document) {
    if (prefersReducedMotion() || isCoarsePointer()) return () => {};

    const cards = root.querySelectorAll('[data-tilt]');
    const cleanups = Array.from(cards).map(bindTilt);

    return () => cleanups.forEach((fn) => fn());
}
