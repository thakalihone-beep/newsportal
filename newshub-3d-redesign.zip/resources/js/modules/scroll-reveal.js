/**
 * Scroll-reveal for [data-reveal] elements using GSAP + ScrollTrigger.
 * Used sparingly: article headers/images and section headings only —
 * never on paragraph/body copy, per the readability requirement.
 */
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

function prefersReducedMotion() {
    return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
}

export function initScrollReveal(root = document) {
    if (prefersReducedMotion()) return () => {};

    const elements = root.querySelectorAll('[data-reveal]');
    const triggers = [];

    elements.forEach((el, i) => {
        const trigger = ScrollTrigger.create({
            trigger: el,
            start: 'top 88%',
            once: true,
            onEnter: () => {
                gsap.to(el, {
                    opacity: 1,
                    y: 0,
                    duration: 0.7,
                    delay: Math.min(i * 0.05, 0.2),
                    ease: 'power3.out',
                    onStart: () => el.classList.add('is-revealed'),
                });
            },
        });
        triggers.push(trigger);
    });

    return () => triggers.forEach((t) => t.kill());
}

/**
 * Subtle parallax for [data-parallax] elements (e.g. the article featured image).
 * Moves the element a few percent slower than scroll — not a full effect, just depth.
 */
export function initParallax(root = document) {
    if (prefersReducedMotion()) return () => {};

    const elements = root.querySelectorAll('[data-parallax]');
    const triggers = [];

    elements.forEach((el) => {
        const trigger = ScrollTrigger.create({
            trigger: el,
            start: 'top bottom',
            end: 'bottom top',
            scrub: 0.6,
            onUpdate: (self) => {
                const shift = (self.progress - 0.5) * 40; // px
                el.style.transform = `translateY(${shift.toFixed(1)}px) scale(1.08)`;
            },
        });
        triggers.push(trigger);
    });

    return () => triggers.forEach((t) => t.kill());
}
